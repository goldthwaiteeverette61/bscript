#!/bin/bash


for i in `seq $1 $2`
do
    echo 端口${i}==========================
    curl http://localhost:${i}5/addresses | jq .ethereum
done

