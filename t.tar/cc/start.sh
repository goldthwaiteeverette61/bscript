#!/bin/bash


for i in `seq $1 $2`
do
    docker start swarm${i}_clef-1-${i}_1 swarm${i}_bee-1_1
done

