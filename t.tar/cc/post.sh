#!/bin/bash


for i in `seq $1 $2`
do
                curl -X POST localhost:${i}5/connect/ip4/183.240.196.12/tcp/1733/p2p/16Uiu2HAkvUHVw8itJ7e79X4tVYv77Lq8De1eay5wcSpJ6gLbZJPn
		sleep 1
                curl -X POST localhost:${i}5/connect/ip4/183.240.196.12/tcp/1735/p2p/16Uiu2HAmEHjpSeVS9xkk3izt1SyxSePsmtKPCYL375NQFuMgcn31
		sleep 1
                curl -X POST localhost:${i}5/connect/ip4/183.240.196.12/tcp/1736/p2p/16Uiu2HAmJd5Xs9b3GUARfsw623woq4EWrGPnG3uiBZg2EgNT6yv8
		sleep 1
                curl -X POST localhost:${i}5/connect/ip4/183.240.196.12/tcp/1737/p2p/16Uiu2HAmQYFT2ibAXkjMEzaK76Gb2KDoHkpDpGsTLch79CHvGMtH
		sleep 1
                curl -X POST localhost:${i}5/connect/ip4/183.240.196.12/tcp/1738/p2p/16Uiu2HAmPzVfdootKiChCqiSrfMhLjEVTtMhWD6GKHDYujKjsMmt
		sleep 1
                curl -X POST localhost:${i}5/connect/ip4/183.240.196.12/tcp/1739/p2p/16Uiu2HAmLCDKaPFv5vpbaVqmpuifGgsktv9Bxw87oEN9VRjawQ5t
	        sleep 1

done


