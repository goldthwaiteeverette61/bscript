#!/bin/bash

docker network create --driver bridge bee-net

if [ ! -d "swarms" ]; then
	mkdir swarms
fi

cd swarms

for i in `seq $1 $2`
do
	if [ ! -d "swarm$i" ]; then
  		mkdir swarm$i
	fi
	
	cd swarm$i
	
	if [ ! -f "docker-compose.yml" ]; then
  		cp ../../docker-compose.yml .
		find -name 'docker-compose.yml'  | xargs perl -pi -e 's|- BEE_DEBUG_API_ENABLE|- BEE_DEBUG_API_ENABLE=true|g'
		find -name 'docker-compose.yml'  | xargs perl -pi -e 's|- BEE_SWAP_ENDPOINT|- BEE_SWAP_ENDPOINT='${3}'|g'
		find -name 'docker-compose.yml'  | xargs perl -pi -e 's|API_ADDR:-1633|API_ADDR:-'${i}'3|g'
		find -name 'docker-compose.yml'  | xargs perl -pi -e 's|P2P_ADDR:-1634|P2P_ADDR:-'${i}'4|g'
		find -name 'docker-compose.yml'  | xargs perl -pi -e 's|1:1635|1:'${i}'5|g'
		find -name 'docker-compose.yml'  | xargs perl -pi -e 's|BEE_PASSWORD|BEE_PASSWORD='${4}'|g'
		find -name 'docker-compose.yml'  | xargs perl -pi -e 's|clef-1|clef-1-'${i}'|g'
		
		
				
		#find -name 'docker-compose.yml'  | xargs perl -pi -e 's|bee-1|bee-'${i}'|g'
		#find -name 'docker-compose.yml'  | xargs perl -pi -e 's|clef-1|clef-'${i}'|g'
	fi
	
	docker-compose up -d
	cd ..
	
done
 



