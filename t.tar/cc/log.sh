#!/bin/bash


for i in `seq $1 $2`
do
	echo "docker logs swarm"${i}"_bee-1_1 --tail 5"=========================== 
	docker logs swarm${i}_bee-1_1 --tail 5
done


