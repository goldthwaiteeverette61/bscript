#!/bin/bash

cd swarms

fn='address_'$(date "+%Y%m%d%H%M%S")'.txt'
touch ${fn}

fn2='aaddress_'$(date "+%Y%m%d%H%M%S")'.txt'
touch ${fn2}


echo "" > ${fn}

for i in `seq $1 $2`
do
    echo 端口${i}:===== >> ${fn}
    curl http://localhost:${i}5/addresses | jq .ethereum  >>  ${fn}

    curl http://localhost:${i}5/addresses | jq .ethereum  >>  ${fn2}
done


echo =========================
echo filename: ${fn}
cat ${fn}

echo =========================
echo filename: ${fn2}
cat ${fn2}
echo ""

